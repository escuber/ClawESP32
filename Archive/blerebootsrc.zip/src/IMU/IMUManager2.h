#ifndef IMU_IMUMANAGER2_H
#define IMU_IMUMANAGER2_H

#include <Arduino.h>

void imuManagerBegin();
void imuManagerUpdate();
void saveCalibrationData();

#endif
