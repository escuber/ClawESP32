#ifndef WHEELIE_LOGIC_H
#define WHEELIE_LOGIC_H

float evaluateThrottle(int inputPWM, float pitch, float accelZ, int rpm);

#endif
