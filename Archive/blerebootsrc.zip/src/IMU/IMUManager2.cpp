#include "IMUManager2.h"
#include <Wire.h>
#include <EEPROM.h>
#include <Adafruit_BNO055.h>
#include <Adafruit_Sensor.h>
#include <deque>
#include <string.h>

#define EEPROM_SIZE 64
#define CALIBRATION_ADDRESS 0

std::deque<float> accelHistory;
const size_t accelWindowSize = 10;
const int FLIP_CONFIRM_COUNT = 5;
int flipDetectionCounter = 0;
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28);
volatile float lastKnownPitch;
const float TILT_THRESHOLD_DEG = 60.0;
const float CRASH_ACCEL_THRESHOLD_G = 2.0;
const unsigned long CRASH_DEBOUNCE_MS = 1000;

static volatile int latestPitch = 0;
static volatile int latestRoll = 0;
static volatile int latestYaw = 0;

static volatile int16_t latestAccelX = 0;
static volatile int16_t latestAccelY = 0;
static volatile int16_t latestAccelZ = 0;
static volatile float pitchRate = 0;

float idlePitchOffset = 0;
unsigned long lastZeroCheck = 0;
bool offsetConfirmed = false;

unsigned long lastCrashTime = 0;
volatile float lastKnownAccelerationG;
const unsigned long offsetCheckInterval = 3000;  // 3 sec of idle required

extern volatile unsigned int currentPWM;
extern int getRPM();

int getPitch() { return latestPitch; }
int getRoll() { return latestRoll; }
int getYaw() { return latestYaw; }

int getAccelX() { return latestAccelX; }
int getAccelZ() { return latestAccelZ; }
int getAccelY() { return latestAccelY; }

float getSmoothedAccel()
{
  if (accelHistory.empty())
    return 1.0;
  float sum = 0;
  for (float a : accelHistory)
  {
    sum += a;
  }
  return sum / accelHistory.size();
}

void saveCalibrationData()
{
  adafruit_bno055_offsets_t calData;
  if (!bno.getSensorOffsets(calData))
  {
    Serial.println("[IMU] Failed to get sensor offsets.");
    return;
  }

  EEPROM.put(CALIBRATION_ADDRESS, calData);
  if (!EEPROM.commit())
  {
    Serial.println("[IMU] EEPROM commit failed!");
    return;
  }

  Serial.println("[IMU] Calibration saved to EEPROM.");

  adafruit_bno055_offsets_t verifyData;
  EEPROM.get(CALIBRATION_ADDRESS, verifyData);

  if (memcmp(&calData, &verifyData, sizeof(calData)) == 0)
  {
    bno.setSensorOffsets(verifyData);
    Serial.println("[IMU] Calibration reloaded and applied.");
  }
  else
  {
    Serial.println("[IMU] Calibration verification failed!");
  }

  static unsigned long lastIMUPrint = 0;

  if (millis() - lastIMUPrint > 1000)
  {
    lastIMUPrint = millis();

    Serial.print("[IMU] Pitch: ");
    Serial.print(getPitch());
    Serial.print(" | Roll: ");
    Serial.print(getRoll());
    Serial.print(" | Yaw: ");
    Serial.print(getYaw());

    Serial.print(" | AccelX: ");
    Serial.print(getAccelX());
    Serial.print(" | AccelY: ");
    Serial.print(getAccelY());
    Serial.print(" | AccelZ: ");
    Serial.println(getAccelZ());
  }
}
bool loadCalibrationData()
{

  adafruit_bno055_offsets_t calData;
  EEPROM.get(CALIBRATION_ADDRESS, calData);

  Serial.println("[IMU] 🔍 Retrieved stored calibration:");
  Serial.printf("  Accel Offset X: %d\n", calData.accel_offset_x);
  Serial.printf("  Gyro Offset X:  %d\n", calData.gyro_offset_x);
  Serial.printf("  Mag Offset X:   %d\n", calData.mag_offset_x);

  if (calData.accel_offset_x == 0 && calData.mag_offset_x == 0)
  {
    Serial.println("[IMU] ❌ No valid calibration data found.");
    return false;
  }

  bno.setMode(adafruit_bno055_opmode_t::OPERATION_MODE_CONFIG);
  // adafruit_bno055_opmode_t::OPERATION_MODE_CONFIG
  delay(25);
  bno.setSensorOffsets(calData);
  delay(10);
  bno.setMode(adafruit_bno055_opmode_t::OPERATION_MODE_NDOF);
  delay(20);
  Serial.println("[IMU] Calibration data loaded.");

  uint8_t sys, gyro, accelStatus, mag;
  bno.getCalibration(&sys, &gyro, &accelStatus, &mag);
  Serial.printf(" | Calib: SYS=%d GYRO=%d ACC=%d MAG=%d\n", sys, gyro, accelStatus, mag);

  return true;
}

float itchRate_zero_offset=0;
void setPitchRateOffsets(){

  int total=0;
  for(int x=0; x<20; x++)
  { 
  imu::Vector<3> gyro = bno.getVector(Adafruit_BNO055::VECTOR_GYROSCOPE);

  // The pitch rate is the Y-axis rotation in the BNO055 coordinate system
  // Units are in radians/second
  float pitch_rate_rad_per_sec = gyro.y();
  pitchRate = pitch_rate_rad_per_sec * 180.0 / M_PI;


    total=total+pitchRate;

    delay(50);

  }
  itchRate_zero_offset=total/20;



}



float getSmoothPitchRate()
{
  static unsigned long previous_filtered_rate = 0;

  float filtered_pitch_rate = 0.9 * previous_filtered_rate + 0.1 * (pitchRate-itchRate_zero_offset);

  previous_filtered_rate=filtered_pitch_rate;
  return filtered_pitch_rate;
}
void imuManagerBegin()
{
  EEPROM.begin(EEPROM_SIZE);
  Wire.begin();

  if (!bno.begin())
  {
    Serial.println("[IMU] BNO055 Connection Failed!");
    return;
  }

  bno.setExtCrystalUse(true);


  //bno.setAxisRemap(1, 0, 2);  // Y, X, Z
  //bno.setAxisSign(0, 1, 0); 
///  bno.setAxisRemap(Adafruit_BNO055::REMAP_CONFIG_P1); // for Y,X,Z
 // bno.setAxisSign(Adafruit_BNO055::REMAP_SIGN_P1);    // for X+,Y-,Z+

//  Serial.println("[IMU] AXSIS REMAPPING done.");
//   bno.setAxisRemap(Adafruit_BNO055::REMAP_Y,
//     Adafruit_BNO055::REMAP_X,
//     Adafruit_BNO055::REMAP_Z);
// bno.setAxisSign(Adafruit_BNO055::REMAP_SIGN_POSITIVE,
//    Adafruit_BNO055::REMAP_SIGN_NEGATIVE,
//    Adafruit_BNO055::REMAP_SIGN_POSITIVE);


  if (loadCalibrationData())
  {
    Serial.println("[IMU] Calibration applied.");
  }
  else
  {
    Serial.println("[IMU] Running without saved calibration.");
  }
  setPitchRateOffsets();
}


void maybeUpdateIdlePitchOffset() {
  static unsigned long idleStart = 0;

  if (currentPWM == 1500 && getRPM() == 0) {
    if (idleStart == 0) idleStart = millis();

    if (millis() - idleStart >= offsetCheckInterval && !offsetConfirmed) {
      float sum = 0;
      for (int i = 0; i < 10; i++) {
        imu::Vector<3> euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
        //sum += euler.yx();
        sum += euler.y();
        delay(10);
      }
      float newOffset = sum / 10.0;

      // 🔐 Reasonableness check
      if (fabs(newOffset) < 5.0) {
        idlePitchOffset = newOffset;
        Serial.print("[IMU] Idle pitch offset set to: ");
        Serial.println(idlePitchOffset);

        // 🔔 Audible confirmation
        tone(8, 880, 300);  // Use a valid tone pin
        offsetConfirmed = true;
      } else {
        Serial.print("[IMU] Ignored pitch offset (too large): ");
        Serial.println(newOffset);
      }
    }
  } else {
    idleStart = 0;
    offsetConfirmed = false;
  }
}

void imuManagerUpdate()
{
  //maybeUpdateIdlePitchOffset();
  

  imu::Vector<3> euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
  //latestPitch = (int16_t)(euler.x());
  latestPitch = (int16_t)(euler.y() - idlePitchOffset);
  
  
  latestRoll = (int16_t)(euler.x());
  latestYaw = (int16_t)(euler.z());

  imu::Vector<3> accel = bno.getVector(Adafruit_BNO055::VECTOR_LINEARACCEL);
  latestAccelX = (int16_t)(accel.x() * 100);
  latestAccelY = (int16_t)(accel.y() * 100);
  latestAccelZ = (int16_t)(accel.z() * 100);
  imu::Vector<3> gyro = bno.getVector(Adafruit_BNO055::VECTOR_GYROSCOPE);

  // The pitch rate is the Y-axis rotation in the BNO055 coordinate system
  // Units are in radians/second
  float pitch_rate_rad_per_sec = gyro.y();
  pitchRate = pitch_rate_rad_per_sec * 180.0 / M_PI;

  // static unsigned long lastCalPrint = 0;
  // if (millis() - lastCalPrint > 1000)
  // {
  //   lastCalPrint = millis();
  //   uint8_t sys, gyro, accelStatus, mag;
  //   bno.getCalibration(&sys, &gyro, &accelStatus, &mag);

  //   Serial.printf("[CAL] SYS=%d GYRO=%d ACC=%d MAG=%d\n", sys, gyro, accelStatus, mag);
  // }
}
