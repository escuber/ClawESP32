#ifndef ADJUST_OUTPUT_H
#define ADJUST_OUTPUT_H

void AdjustOutputInit();
//int AdjustOutputEvaluate(int inputPWM);
int AdjustOutputEvaluate(int inputPWM);

#endif