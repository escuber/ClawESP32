

#include <ESP32Servo.h>
#include <ArduinoBLE.h> // ✅ ArduinoBLE for safe BLE operations
#include "BluetoothRPM.h"
#include "ToneModule.h"
#include "IMU/IMUManager2.h"
#include "WirelessManager_v2.h"
#include "AdjustOutput.h"
#define PWM_INPUT_PIN 2
#define PWM_OUTPUT_PIN 3
BluetoothRPM rpmReader;
Servo throttleServo;
// unsigned int currentPWM;
volatile unsigned int currentPWM;
unsigned int currentRPM;
volatile unsigned long measuredPulseWidth = 1500;
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
unsigned long pulseStartTime = 0;

TaskHandle_t echoTaskHandle;

BLEDevice peripheral;
BLECharacteristic rpmCharacteristic;
const char *targetDeviceName = "HW_BLE7881798"; // ✅ Correct BLE device
const char *targetCharacteristicUUID = "f1f2";  // ✅ Correct short characteristic UUID

int lastRPM = -1;
bool deviceConnected = false;

void rpmCallback(int rpm)
{
  //Serial.print("[RPM CALLBACK] Got RPM: ");
  //Serial.println(rpm);
  currentRPM = rpm;

  //Serial.print("[RPM] ");
  //Serial.println(rpm);
  static int lastRPM = -1;
  if (abs(rpm - lastRPM) > 25)
  { // Only print if RPM changes more than 25
    Serial.print("[RPM] ");
    Serial.println(rpm);
    currentRPM = rpm;
  }
  currentRPM = rpm;
}
int getRPM() { return currentRPM; }
void IRAM_ATTR throttleInterrupt()
{
  if (digitalRead(PWM_INPUT_PIN) == HIGH)
  {
    pulseStartTime = micros();
  }
  else
  {
    unsigned long endTime = micros();
    portENTER_CRITICAL_ISR(&mux);
    measuredPulseWidth = endTime - pulseStartTime;
    portEXIT_CRITICAL_ISR(&mux);
  }
}

void echoTask(void *parameter)
{
  ////unsigned long safePulse = 1500;
  unsigned long lastLoggedPulse = 1500;

  for (;;)
  {
    portENTER_CRITICAL(&mux);
    currentPWM = measuredPulseWidth;
    portEXIT_CRITICAL(&mux);

    if (currentPWM < 900 || currentPWM > 2100)
    {
      currentPWM = 1500;
    }

    //char eventBuffer[24] = "";
    int adjustedPWM = currentPWM;
    //int adjustedPWM = AdjustOutputEvaluate(currentPWM);
    throttleServo.writeMicroseconds(adjustedPWM);

    static unsigned long lastPulseLog = 0;
// if (millis() - lastPulseLog > 1000) {
//   Serial.print("[Echo] PWM: ");
//   Serial.print(currentPWM);
//   Serial.print(" | Adjusted: ");
//   Serial.println(adjustedPWM);
//   lastPulseLog = millis();
// }
    //throttleServo.writeMicroseconds(currentPWM);

    // Blip monitor
    // if (abs((long)currentPWM - (long)lastLoggedPulse) > 50)
    // {
    //   Serial.print("[BLIP DETECTED] New Pulse: ");
    //   Serial.print(currentPWM);
    //   Serial.println(" us");
    //   lastLoggedPulse = currentPWM;
    // }
    imuManagerUpdate();
    

    vTaskDelay(10 / portTICK_PERIOD_MS);
  }
}

void setup()
{
  Serial.begin(115200);
  while (!Serial) {  };
  startWirelessManager();

  pinMode(PWM_INPUT_PIN, INPUT);
  attachInterrupt(digitalPinToInterrupt(PWM_INPUT_PIN), throttleInterrupt, CHANGE);

  throttleServo.setPeriodHertz(50);
  throttleServo.attach(PWM_OUTPUT_PIN, 1000, 2000);
  throttleServo.writeMicroseconds(1500);

  AdjustOutputInit();
  
  initToneModule(8);  // Whatever pin your buzzer is on
  ///playTone(TONE_BLUETOOTH_NOT_CONNECTED);
  ///playTone(TONE_BLUETOOTH_NOT_CONNECTED);  // Test it
  //delay(3000);
  //}

  rpmReader.begin();
  rpmReader.onRPM(rpmCallback);
  imuManagerBegin();

  xTaskCreatePinnedToCore(
      echoTask, "EchoTask", 2000, NULL, 1, &echoTaskHandle, 1);

  ///startWirelessManager();
}
// BLEDevice peripheral;

void loop()
{

  rpmReader.update(); // Drive the BLE state machine!

  // if (Serial.available()) {
  //   String input = Serial.readStringUntil('\n');
  //   input.trim();  // Clean up newline characters

  //   if (input == "save") {
  //     saveCalibrationData();  // 🔥 this is the one
  //   }
  // }
}