#include "AdjustOutput.h"
#include "BluetoothRPM.h"

#include "IMU/IMUManager2.h"
#include <Arduino.h>

extern volatile unsigned int currentPWM;
extern int getPitch(); // Degrees as int
extern int getSmoothPitchRate(); // Degrees/sec as int
extern int getRPM();

const int NEUTRAL_PWM = 1500;
const int MAX_PWM = 2000;
const int MIN_PWM = 1000;
const float MAX_SAFE_PITCH = 5.0f;
const float CRITICAL_PITCH = 8.0f;
const float PITCH_RATE_LIMIT = 10.0f;
const float Kp = 0.8f;
const float Ki = 0.1f;
const float Kd = 0.4f;

static float integratedError = 0;
static float previousError = 0;
static float previousThrottle = NEUTRAL_PWM;
static unsigned long lastTime = 0;

void AdjustOutputInit() {
    integratedError = 0;
    previousError = 0;
    previousThrottle = NEUTRAL_PWM;
    lastTime = millis();
}

int wheelieThrottlePID(int basePWM) {
    float pitch = getPitch();
    float pitchRate = getSmoothPitchRate();
    unsigned long now = millis();
    float dt = (now - lastTime) / 1000.0f;
    lastTime = now;

    float error = pitch;  // target is 0
    float derivative = (error - previousError) / dt;

    if (pitch > CRITICAL_PITCH || pitchRate > PITCH_RATE_LIMIT) {
        integratedError = 0;
        previousError = error;
        previousThrottle = NEUTRAL_PWM + (basePWM - NEUTRAL_PWM) * 0.3f;
        return (int)previousThrottle;
    }

    if (abs(error) < MAX_SAFE_PITCH) {
        integratedError += error * dt;
    } else {
        integratedError = 0;
    }

    float adjustment = Kp * error + Ki * integratedError + Kd * derivative;
    float newThrottle = basePWM - adjustment;

    newThrottle = constrain(newThrottle, MIN_PWM, MAX_PWM);
    newThrottle = 0.7f * newThrottle + 0.3f * previousThrottle;

    previousThrottle = newThrottle;
    previousError = error;

    Serial.print("[WheeliePID] Pitch: ");
    Serial.print(pitch);
    Serial.print(" | Rate: ");
    Serial.print(pitchRate);
    Serial.print(" | Error: ");
    Serial.print(error);
    Serial.print(" | Out: ");
    Serial.println(newThrottle);

    return (int)newThrottle;
}

int AdjustOutputEvaluate(int inputPWM) {
    int pwm = inputPWM;

    // Only apply reverse limiter if actually in reverse (>1500)
    if (pwm > NEUTRAL_PWM && getRPM() > 1000) {
        float percentIntoReverse = (float)(pwm - NEUTRAL_PWM) / (MAX_PWM - NEUTRAL_PWM);
        if (percentIntoReverse > 0.1f) {
            pwm = NEUTRAL_PWM + (MAX_PWM - NEUTRAL_PWM) * 0.1f;
            Serial.println("[AdjustOutput] Reverse Max 10% limiting");
        }
    }

    // Apply PID-based wheelie throttle control
    return wheelieThrottlePID(pwm);
}
