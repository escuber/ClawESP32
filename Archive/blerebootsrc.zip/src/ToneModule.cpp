#include "ToneModule.h"
#include <Arduino.h>

static int tonePin = -1;

void initToneModule(int pin) {
  tonePin = pin;
  pinMode(tonePin, OUTPUT);
}

void playTone(ToneEvent event) {
  if (tonePin == -1) return;  // Not initialized

  switch (event) {
    case TONE_IDLE_OFFSET_SET:
      tone(tonePin, 880, 300);  // High short beep
      break;

    case TONE_BLUETOOTH_NOT_CONNECTED:
      tone(tonePin, 440, 150);
      delay(200);
      tone(tonePin, 440, 150);
      break;

    case TONE_ERROR:
      tone(tonePin, 200, 400);
      break;

    case TONE_WARNING:
      tone(tonePin, 600, 200);
      delay(100);
      tone(tonePin, 600, 200);
      break;

    default:
      // No tone
      break;
  }
}