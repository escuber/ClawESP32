#include "WirelessManager_v2.h"
#include <esp_now.h>
#include <WiFi.h>
#include <esp_wifi.h>

extern volatile unsigned int currentPWM;
extern int getPitch();
extern int getRoll();
extern int getYaw();
extern int getRPM();
extern int getAccelX();
extern int getAccelZ();
extern int getAccelY();

static TelemetryPacket lastTelemetry;
static TelemetryPacket lastSent = {0};
static char pendingEvent[24] = ""; // Shared event buffer

uint8_t peerAddress[] = {0xDC, 0xDA, 0x0C, 0x21, 0x5F, 0xD4};
TaskHandle_t wirelessTaskHandle;

void onDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {}

// bool isSignificantChange(const TelemetryPacket& a, const TelemetryPacket& b) {
//   return true; // Always send for now
// }

bool isSignificantChange(const TelemetryPacket &a, const TelemetryPacket &b)
{
  return abs(a.pwm - b.pwm) > 5 ||
         abs(a.rpm - b.rpm) > 50 ||
         strcmp(a.event, b.event) != 0;
}

void logTelemetryEvent(const char *eventTag)
{
  strncpy(pendingEvent, eventTag, sizeof(pendingEvent));
}

void wirelessTask(void *parameter)
{
  Serial.println("[WirelessManager] Task running on Core 0.");

  for (;;)
  {
    TelemetryPacket packet;

    packet.pwm = currentPWM;
    packet.rpm = getRPM();
    packet.pitch = getPitch() * 100;
    packet.roll = getRoll() * 100;
    packet.yaw = getYaw() * 100;
    packet.accelX = getAccelX();
    packet.accelY = getAccelY();
    packet.accelZ = getAccelZ();

    strncpy(packet.event, pendingEvent, sizeof(packet.event));

    lastTelemetry = packet;

    if (isSignificantChange(packet, lastSent))
    {
      static unsigned long lastSendTime = 0;
      unsigned long now = millis();
      if (now - lastSendTime >= 100)
      {
        // esp_err_t result = esp_now_send(...);

        esp_err_t result = esp_now_send(peerAddress, (uint8_t *)&packet, sizeof(packet));
        if (result != ESP_OK)
        {
          Serial.print("[WirelessManager] ESP-NOW send failed. Error code: ");
          Serial.println(result);
        }
        else
        {
          Serial.print("[WirelessManager] Sent event: pwm: ");
          Serial.print(currentPWM);
          Serial.println(packet.event);
          lastSent = packet;
          pendingEvent[0] = '\0'; // Clear only after successful send
        }
        lastSendTime = now;
      }
    }

    vTaskDelay(100 / portTICK_PERIOD_MS);
  }
}

void startWirelessManager()
{
  Serial.println("[WirelessManager] Initializing...");

  WiFi.mode(WIFI_STA);
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(6, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);

  if (esp_now_init() != ESP_OK)
  {
    Serial.println("[WirelessManager] ESP-NOW init failed.");
    return;
  }

  esp_now_register_send_cb(onDataSent);

  esp_now_peer_info_t peerInfo = {};
  memcpy(peerInfo.peer_addr, peerAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;

  if (!esp_now_is_peer_exist(peerAddress))
  {
    if (esp_now_add_peer(&peerInfo) != ESP_OK)
    {
      Serial.println("[WirelessManager] Failed to add peer.");
      return;
    }
  }

  Serial.println("[WirelessManager] ESP-NOW Ready. Starting task...");
  Serial.print("WiFi Channel: ");
  Serial.println(WiFi.channel());
  xTaskCreatePinnedToCore(
      wirelessTask,
      "WirelessTask",
      4096,
      NULL,
      1,
      &wirelessTaskHandle,
      0);
}

const TelemetryPacket &getLastSentTelemetry()
{
  return lastTelemetry;
}
